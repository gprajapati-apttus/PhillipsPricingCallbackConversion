﻿namespace Apttus.Lightsaber.Nokia.Pricing
{
    public class CurrencyTypeQueryModel
    {
        public string Id { get; set; }

        public decimal? ConversionRate { get; set; }
    }
}
