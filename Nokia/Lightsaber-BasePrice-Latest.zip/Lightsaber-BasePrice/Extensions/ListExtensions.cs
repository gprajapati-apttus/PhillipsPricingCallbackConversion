﻿using System.Collections.Generic;
using System.Linq;

namespace Apttus.Lightsaber.Nokia.Pricing
{
    /// <summary>
    /// List extensions method for Apex
    /// </summary>
    public static class ListExtensions
    {
        public static bool isEmpty<T>(this List<T> list)
        {
            return list == null || (!list.Any());
        }

        public static int size<T>(this List<T> list)
        {
            return list.Count;
        }
    }
}
