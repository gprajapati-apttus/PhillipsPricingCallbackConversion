﻿using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace Apttus.Lightsaber.Nokia.Totalling
{

    /// <summary>
    /// String Exntesion for Apex Code
    /// </summary>
    public static class StringExtensions
    {
        public static string trim(this String source)
        {
            if (source != null)
            {
                return source.Trim();
            }

            return string.Empty;
        }

        public static bool equals(this String source, string destination)
        {
            if (source == null) return false;

            return source.Equals(destination);
        }

        public static bool equalsIgnoreCase(this String source, string destination)
        {
            if (source == null) return false;

            return source.Equals(destination, StringComparison.OrdinalIgnoreCase);
        }

        public static int size(this String[] source)
        {
            if (source != null)
            {
                return source.Count();
            }

            return 0;
        }

        public static string[] split(this string source, string separator)
        {
            if (source != null)
            {
                return source.Split(separator.ToArray<char>()).Select(x => x.trim()).ToArray();
            }

            return null;
        }
    }
}
