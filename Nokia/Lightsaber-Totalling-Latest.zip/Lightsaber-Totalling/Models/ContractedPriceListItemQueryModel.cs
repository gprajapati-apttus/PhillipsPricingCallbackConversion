﻿namespace Apttus.Lightsaber.Nokia.Totalling
{
    public class ContractedPriceListItemQueryModel
    {
        public string Id { get; set; }

        public string Apttus_Config2__PriceListId__c { get; set; }

        public string Contracted__c { get; set; }

        public decimal? Partner_Price__c { get; set; }
    }
}
