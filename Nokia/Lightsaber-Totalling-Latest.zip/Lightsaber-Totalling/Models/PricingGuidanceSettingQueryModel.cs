﻿namespace Apttus.Lightsaber.Nokia.Totalling
{
    public class PricingGuidanceSettingQueryModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public decimal? Threshold__c { get; set; }
    }
}
