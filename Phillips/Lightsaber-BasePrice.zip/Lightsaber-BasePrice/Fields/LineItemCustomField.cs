﻿namespace Apttus.Lightsaber.Phillips.Pricing
{
    public class LineItemCustomField
    {
        public const string APTS_Local_Bundle_Header__c = "APTS_Local_Bundle_Header__c";
        public const string APTS_Local_Bundle_Component__c = "APTS_Local_Bundle_Component__c";
        public const string APTS_Extended_Quantity__c = "APTS_Extended_Quantity__c";
        public const string APTS_Bundle_Quantity__c = "APTS_Bundle_Quantity__c";
        public const string APTS_Extended_List_Price__c = "APTS_Extended_List_Price__c";
        public const string APTS_Option_Unit_Price__c = "APTS_Option_Unit_Price__c";
        public const string APTS_Target_Price_SPOO__c = "APTS_Target_Price_SPOO__c";
        public const string APTS_Escalation_Price_SPOO__c = "APTS_Escalation_Price_SPOO__c";
        public const string APTS_Product_ID_SPOO__c = "APTS_Product_ID_SPOO__c";
        public const string APTS_System_Type__c = "APTS_System_Type__c";
        public const string APTS_Valuation_Class__c = "APTS_Valuation_Class__c";
        public const string APTS_Service_List_Price__c = "APTS_Service_List_Price__c";
        public const string APTS_Minimum_Price_Service__c = "APTS_Minimum_Price_Service__c";
        public const string APTS_Cost_Service__c = "APTS_Cost_Service__c";
        public const string APTS_VolumeTier__c = "APTS_VolumeTier__c";
        public const string APTS_ContractDiscount__c = "APTS_ContractDiscount__c";
        public const string APTS_Local_Bundle_Component_Flag__c = "APTS_Local_Bundle_Component_Flag__c";
    }
}
