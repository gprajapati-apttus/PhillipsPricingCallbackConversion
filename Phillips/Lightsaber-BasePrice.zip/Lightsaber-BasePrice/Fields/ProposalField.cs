﻿namespace Apttus.Lightsaber.Phillips.Pricing
{
    public class ProposalField
    {
        public const string Account_Sold_to__c = "Account_Sold_to__c";
    }
}
