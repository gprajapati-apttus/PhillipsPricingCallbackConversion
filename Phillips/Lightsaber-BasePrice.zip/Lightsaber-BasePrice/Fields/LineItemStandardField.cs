﻿namespace Apttus.Lightsaber.Phillips.Pricing
{
    public class LineItemStandardField
    {
        public const string Apttus_Config2__Description__c = "Apttus_Config2__Description__c";
    }
}
