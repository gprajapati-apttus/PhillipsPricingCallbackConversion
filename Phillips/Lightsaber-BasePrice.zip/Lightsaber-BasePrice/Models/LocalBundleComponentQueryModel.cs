﻿namespace Apttus.Lightsaber.Phillips.Pricing
{
    public class LocalBundleComponentQueryModel
    {
        public string Id { get; set; }
        public string APTS_Local_Bundle__c { get; set; }
        public string APTS_Parent_Bundle__c { get; set; }
        public string APTS_Parent_Local_Bundle__c { get; set; }
    }
}
