﻿using System;

namespace Apttus.Lightsaber.Phillips.Pricing
{
    public class RelatedAgreementQueryModel
    {
        public DateTime? Apttus__Contract_Start_Date__c { get; set; }

        public DateTime? Apttus__Contract_End_Date__c { get; set; }
    }
}
