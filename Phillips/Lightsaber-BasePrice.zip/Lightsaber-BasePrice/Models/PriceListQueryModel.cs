﻿namespace Apttus.Lightsaber.Phillips.Pricing
{
    public class PriceListQueryModel
    {
        public string APTS_Related_Agreement__c { get; set; }
    }
}
