﻿namespace Apttus.Lightsaber.Phillips.Totalling
{
    public class LineItemStandardRelationshipField
    {
        public const string Apttus_Config2__OptionId__r_Apttus_Config2__ConfigurationType__c = "Apttus_Config2__OptionId__r.Apttus_Config2__ConfigurationType__c";
        public const string Apttus_Config2__ProductId__r_Apttus_Config2__ProductType__c = "Apttus_Config2__ProductId__r.Apttus_Config2__ProductType__c";
        public const string Apttus_Config2__OptionId__r_Main_Article_Group_ID__c = "Apttus_Config2__OptionId__r.Main_Article_Group_ID__c";
        public const string Apttus_Config2__OptionId__r_Business_Unit_ID__c = "Apttus_Config2__OptionId__r.Business_Unit_ID__c";
        public const string Apttus_Config2__ProductId__r_Main_Article_Group_ID__c = "Apttus_Config2__ProductId__r.Main_Article_Group_ID__c";
        public const string Apttus_Config2__ProductId__r_Business_Unit_ID__c = "Apttus_Config2__ProductId__r.Business_Unit_ID__c";
        public const string Apttus_Config2__ProductId__r_APTS_SPOO_Type__c = "Apttus_Config2__ProductId__r.APTS_SPOO_Type__c";
        public const string Apttus_Config2__ProductId__r_APTS_Type__c = "Apttus_Config2__ProductId__r.APTS_Type__c";
        public const string Apttus_Config2__ProductId__r_APTS_CLOGS__c = "Apttus_Config2__ProductId__r.APTS_CLOGS__c";
    }
}
