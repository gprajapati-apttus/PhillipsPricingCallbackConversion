﻿namespace Apttus.Lightsaber.Phillips.Totalling
{
    public class ProposalField
    {
        public const string Apttus_Proposal__Payment_Term__c = "Apttus_Proposal__Payment_Term__c";
        public const string APTS_Inco_Term__c = "APTS_Inco_Term__c";
    }
}
