﻿namespace Apttus.Lightsaber.Phillips.Totalling
{
    public class PriceListQueryModel
    {
        public string APTS_Payment_Term_Credit_Terms__c { get; set; }

        public string APTS_Inco_Terms__c { get; set; }

        public string Apttus_Config2__ContractNumber__c { get; set; }
    }
}
