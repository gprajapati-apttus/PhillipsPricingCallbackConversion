﻿namespace Apttus.Lightsaber.Phillips.Totalling
{
    public class ProcurementApprovalQueryModel
    {
        public string Id { get; set; }

        public decimal? APTS_Threshold_Value__c { get; set; }

        public string APTS_CLOGS__c { get; set; }
    }
}
